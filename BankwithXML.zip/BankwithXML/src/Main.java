import atm.ATM;
import card.Card;
import xmlParser.Parser;

import java.util.*;

public class Main {
    static Scanner input = new Scanner(System.in);


    public static void main(String[] args) {

        //XmlParser
        List<Card> cardList = new Parser().xmlParser();
        ATM atm = new ATM();
        SharedResource sharedResource = new SharedResource(cardList, atm);
        while (true) {
            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    sharedResource.getMoney();
                }
            });
            thread.start();

        }

    }

}

