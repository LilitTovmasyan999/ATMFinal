package banks;

public class HSBCBank extends Bank {

    static HSBCBank hsbcBank;


    private HSBCBank() {
        super();
    }
    public static HSBCBank getHSBCBankInstance() {
        if (hsbcBank == null) {
            hsbcBank = new HSBCBank();
        }
        return hsbcBank;
    }
}

