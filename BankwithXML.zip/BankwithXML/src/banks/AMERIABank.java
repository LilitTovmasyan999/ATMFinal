package banks;


import account.Account;

import java.util.Map;

public class AMERIABank extends Bank {
    static AMERIABank ameriaBank;

    private AMERIABank() {
        super();
    }

    public static AMERIABank getAmeriaBankInstance() {
        if (ameriaBank == null) {
            ameriaBank = new AMERIABank();
        }
        return ameriaBank;
    }
}
