package managers;

public interface BankManger {
    void getMoney(int amount, String id);
    boolean checkAmount(int amount, String id);
}
