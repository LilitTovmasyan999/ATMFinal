package managers;

import atm.ATM;

public interface ATMManager {
    boolean checkMoney(int amount, ATM ATM);
    void redueeBalance(int amount, ATM ATM);
}
