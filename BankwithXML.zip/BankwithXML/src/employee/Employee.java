package employee;

public class Employee  {
    private String fname;
    private String lname;

}
