import account.Account;
import atm.ATM;
import banks.Bank;
import card.Card;
import managerImplement.ATMManagerImplement;
import managerImplement.BankManagerImplement;
import xmlParser.Parser;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SharedResource {

    private boolean flag = true;

    private List<Card> cardList;
    private ATM atm;


    public SharedResource(List<Card> cardList, ATM atm) {
        this.cardList = cardList;
        this.atm = atm;
    }


    public synchronized void getMoney() {
        while (!flag) {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        flag = false;
        int index = (int) (Math.random() * cardList.size());
        //RandomCard
        Card thiscard = cardList.get(index);
        //RandomCardNumber
        String thiscardnumber = thiscard.getCardnumber();

        //AccountMap
        Map<String, Account> accountMap = new HashMap<>();
        for (int i = 0; i < cardList.size(); i++) {
            accountMap.put(cardList.get(i).getCardnumber(), new Account(cardList.get(i).getCardnumber(), 2000));
        }

        List<Account> accountList = new ArrayList<>();
        for (int i = 0; i < cardList.size(); i++) {
            accountList.add(new Account(cardList.get(i).getCardnumber(), 2000));
        }


        //BankInstance
        Bank thiscardBank = thiscard.getIssuerbank();
        thiscardBank.setAccounts(accountMap);


        System.out.println("valid card");
        System.out.print("Take money from atm($): ");
        int money = Main.input.nextInt();

        atm.setBankManagerImplement(new BankManagerImplement(thiscardBank, money, thiscardnumber));
        atm.setBank(thiscardBank);
        atm.setATMManagerImplement(new ATMManagerImplement());

        atm.withDraw(money, thiscardnumber);

        flag = true;
        System.out.println("ATM balance " + atm.getBalance());
        notifyAll();


    }


}
