package atm;

import banks.Bank;
import exceptions.ATMWorkErrorException;
import exceptions.LessMoneyException;
import managerImplement.BankManagerImplement;
import managerImplement.ATMManagerImplement;

public class ATM {
    private int balance = 5000;
    private Bank bank;
    private BankManagerImplement bankManagerImplement;
    private ATMManagerImplement ATMManagerImplement;

    public ATM() {


    }


    public Bank getBank() {
        return bank;
    }

    public void setBank(Bank bank) {
        this.bank = bank;
    }

    public BankManagerImplement getBankManagerImplement() {
        return bankManagerImplement;
    }

    public void setBankManagerImplement(BankManagerImplement bankManagerImplement) {
        this.bankManagerImplement = bankManagerImplement;
    }

    public managerImplement.ATMManagerImplement getATMManagerImplement() {
        return ATMManagerImplement;
    }

    public void setATMManagerImplement(managerImplement.ATMManagerImplement ATMManagerImplement) {
        this.ATMManagerImplement = ATMManagerImplement;
    }

    public synchronized void withDraw(int amount, String cardNumber) {
        if (ATMManagerImplement.checkMoney(amount,this)) {
            if (bank.checkAmount(amount, cardNumber)) {
                bankManagerImplement.BankManagerMethod();
                ATMManagerImplement.redueeBalance(amount,this);
                System.out.println("Get your " + amount + "$");
            }
            else {
                try {
                    throw new LessMoneyException();
                } catch (LessMoneyException e) {
                    e.printStackTrace();
                }

            }
        }
        else {
            try {
                throw new ATMWorkErrorException();
            } catch (ATMWorkErrorException e) {
                e.printStackTrace();
            }
        }

    }
//    public ATM(int balance) {
//        this.balance = balance;
//    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }
}
