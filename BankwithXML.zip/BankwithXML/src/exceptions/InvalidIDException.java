package exceptions;

public class InvalidIDException extends MyException {
    public InvalidIDException() {
        System.err.println("Invalid card");
    }
}