package enums;

import banks.AMERIABank;
import banks.BankCreater;
import banks.HSBCBank;


public  enum IssuerBank implements BankCreater {
    AMERIA {
        @Override
        public AMERIABank getInstance() {
            return  AMERIABank.getAmeriaBankInstance();
        }
    },
    HSBC {
        @Override
        public HSBCBank getInstance() {
            return HSBCBank.getHSBCBankInstance();
        }
    };

}
